import WizardCreateSubs from "./components/WizardCreateSubs";

const index = () => {
  return (
    <>
      <WizardCreateSubs/>
    </>
  );
};


export default index