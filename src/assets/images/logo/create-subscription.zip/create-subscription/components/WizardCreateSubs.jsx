import Card from "@/components/ui/Card";
import Icon from "@/components/ui/Icon";
import { useState, useEffect } from "react";
import StepOne from "../steps/stepone";
import StepTwo from "../steps/steptwo";
import StepThree from "../steps/stepthree";
import useStepperStore from "@/store/StepperStore";
import useCurrentStepsCreateSubs from "@/store/subscription/useCurrentSteps";

const steps = [
  {
    id: 1,
    title: "Partner KSO",
  },
  {
    id: 2,
    title: "Technical Data",
  },
  {
    id: 3,
    title: "Agreement KSO",
  },
];

const WizardCreateSubs = () => {
  const { stepper, changeStepper } = useStepperStore();
  const { currentSteps } = useCurrentStepsCreateSubs();
  const [stepNumber, setStepNumber] = useState(stepper || 0);
  const [title, setTitle] = useState("Create Partner KSO");

  useEffect(() => {
    if (stepNumber == 0) {
      setTitle("Partner KSO");
    } else if (stepNumber == 1) {
      setTitle("Technical Data");
    } else if (stepNumber == 2) {
      setTitle("Agreement KSO");
    }
    console.log(stepper);
  }, [setStepNumber, stepNumber]);
  // find current step schema
  let currentStepSchema;

  useEffect(() => {
    //console.log("step number changed");
  }, [stepNumber]);

  const handlePrev = () => {
    setStepNumber(stepNumber - 1);
  };

  const handleNext = () => {
    setStepNumber(stepNumber + 1);
  };

  return (
    <div>
      <Card title={title}>
        <div>
          <div className="flex z-[5] items-center relative justify-evenly md:mx-24">
            {steps.map((item, i) => (
              <div onClick={() => setStepNumber(item.id - 1)} className="cursor-pointer relative z-[1] items-center item flex flex-start flex-1 last:flex-none group" key={i}>
                <div
                  className={`${
                    stepNumber >= i
                      ? "bg-slate-900 text-white ring-slate-900 ring-offset-2 dark:ring-offset-slate-500 dark:bg-slate-900 dark:ring-slate-900"
                      : "bg-white ring-slate-900 ring-opacity-70  text-slate-900 dark:text-slate-300 dark:bg-slate-600 dark:ring-slate-600 text-opacity-70"
                  }  transition duration-150 icon-box md:h-12 md:w-12 h-7 w-7 rounded-full flex flex-col items-center justify-center relative z-[66] ring-1 md:text-lg text-base font-medium`}
                >
                  {stepNumber <= i ? (
                    <span> {i + 1}</span>
                  ) : (
                    <span className="text-3xl">
                      <Icon icon="bx:check-double" />
                    </span>
                  )}
                </div>

                <div className={`${stepNumber > i ? "bg-slate-900 dark:bg-slate-700" : "bg-[#E0EAFF] dark:bg-slate-700"} absolute top-1/2 h-[2px] w-full`}></div>
                <div
                  className={` ${
                    stepNumber >= i ? " text-slate-900 dark:text-slate-300" : "text-slate-500 dark:text-slate-300 dark:text-opacity-40"
                  } absolute top-full text-base md:leading-6 mt-3 transition duration-150 md:opacity-100 opacity-0 group-hover:opacity-100`}
                >
                  <span className="w-max text-center md:flex md:-ml-8">{item.title}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="conten-box md:mt-20 mt-10 md:mx-8">
            {stepNumber == 0 && <StepOne />}
            {stepNumber == 1 && <StepTwo handleNextParent={handleNext} currentSteps={currentSteps} />}
            {stepNumber == 2 && <StepThree />}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default WizardCreateSubs;
