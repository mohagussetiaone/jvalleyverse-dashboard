import React from "react";
import { useTitikLokasi } from "@/store/Coordinate";

function Panorama() {
  const { currentLokasi } = useTitikLokasi();

  return (
    <iframe
      title="Street View"
      className="h-96 w-full"
      frameBorder="0"
      loading="lazy"
      allowFullScreen
      src={`https://maps.googleapis.com/maps/embed/v1/streetview?key=AIzaSyBWmWOR1yXfus5CWRxo2lE2nMT989vJKGk&heading=151.78&pitch=0&location=${currentLokasi.lat},${currentLokasi.lng}`}
    ></iframe>
  );
}

export default Panorama;
