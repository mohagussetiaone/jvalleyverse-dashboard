import React, { useState, useEffect } from "react";
import { useMap, useMapsLibrary } from "@vis.gl/react-google-maps";
import { useFAT,useTitikLokasi } from "@/store/Coordinate";
import { decode } from "@mapbox/polyline";
function Direction({ kirimData, getGeocode, setAddress }) {
  const map = useMap();
  const routesLibrary = useMapsLibrary("routes");
  const [polylines, setPolylines] = useState([]);
  const [markers, setMarkers] = useState([]);
  const [showPanorama, setShowPanorama] = useState(false); // state untuk mengontrol visibilitas panorama
  const { dataDestination, setDataCurrentLokasi, currentLokasi } =
    useTitikLokasi();
  const { setAlamat, dataFAT } = useFAT();

  useEffect(() => {
    // Effect untuk menggambar polylines pada peta
    if (!routesLibrary || !map || !dataDestination) return;

    const dummyData = [dataDestination];

    const newPolylines = dummyData.map((encodedPolyline, index) => {
      const decodedPath = decode(encodedPolyline);
      const path = decodedPath.map((point) => ({
        lat: point[0],
        lng: point[1],
      }));

      const polyline = new google.maps.Polyline({
        path: path,
        geodesic: true,
        strokeColor: "#37ABD9",
        strokeOpacity: 0.8,
        strokeWeight: 4,
      });

      polyline.setMap(map);

      return polyline;
    });

    setPolylines(newPolylines);

    // Cleanup when unmounting
    return () => {
      newPolylines.forEach((polyline) => polyline.setMap(null));
    };
  }, [routesLibrary, map]);

  useEffect(() => {
    if (!map || !polylines.length) {
      const firstPoint = {
        lat: currentLokasi.lat,
        lng: currentLokasi.lng,
      };

      const firstMarker = new google.maps.Marker({
        position: firstPoint,
        map: map,
        draggable: true,
        title: "Titik awal",
        icon: {
          url: "https://cdn-icons-png.flaticon.com/512/6735/6735694.png",
          scaledSize: new google.maps.Size(40, 40), // Ukuran gambar marker
        },
      });

      // Event listener untuk menampilkan panorama ketika marker pertama di-drag
      google.maps.event.addListener(
        firstMarker,
        "dragend",
        async function (event) {
          const a = {
            lat: event.latLng.lat(),
            lng: event.latLng.lng(),
          };
          setDataCurrentLokasi(a);
          kirimData(event.latLng.lat(), event.latLng.lng());
          try {
            const response = await fetch(
              `https://maps.googleapis.com/maps/api/geocode/json?latlng=${event.latLng.lat()},${event.latLng.lng()}&key=${
                import.meta.env.VITE_GOOGLE_MAPS_APIKEY
              }`
            );

            if (!response.ok) {
              throw new Error("Failed to fetch address.");
            }

            const data = await response.json();
            if (data.results.length > 0) {
              setAddress(data.results[0].formatted_address);
              setAlamat(data.results[0].formatted_address);
            } else {
              console.log("No address found.");
            }
          } catch (error) {
            console.error("Error fetching address:", error);
          }
        }
      );

      // Update markers state
      setMarkers([firstMarker]);

      // Cleanup when unmounting
      return () => {
        firstMarker.setMap(null);
      };
    } else {
      // Ambil titik-titik pertama dari polyline pertama
      const firstPolyline = polylines[0];
      const firstPath = firstPolyline.getPath();
      const firstPoint = firstPath.getAt(0);

      const firstMarker = new google.maps.Marker({
        position: firstPoint,
        map: map,
        draggable: true,
        title: "Titik awal",
        icon: {
          url: "https://cdn-icons-png.flaticon.com/512/6735/6735694.png",
          scaledSize: new google.maps.Size(40, 40), // Ukuran gambar marker
        },
      });

      // Event listener untuk menampilkan panorama ketika marker pertama di-drag
      google.maps.event.addListener(
        firstMarker,
        "dragend",
        async function (event) {
          const a = {
            lat: event.latLng.lat(),
            lng: event.latLng.lng(),
          };
          setDataCurrentLokasi(a);
          kirimData(event.latLng.lat(), event.latLng.lng());
          try {
            const response = await fetch(
              `https://maps.googleapis.com/maps/api/geocode/json?latlng=${event.latLng.lat()},${event.latLng.lng()}&key=${
                import.meta.env.VITE_GOOGLE_MAPS_APIKEY
              }`
            );

            if (!response.ok) {
              throw new Error("Failed to fetch address.");
            }

            const data = await response.json();
            if (data.results.length > 0) {
              setAddress(data.results[0].formatted_address);
              setAlamat(data.results[0].formatted_address);
            } else {
              console.log("No address found.");
            }
          } catch (error) {
            console.error("Error fetching address:", error);
          }
        }
      );

      // Ambil titik-titik terakhir dari polyline terakhir
      const lastPolyline = polylines[polylines.length - 1];
      const lastPath = lastPolyline.getPath();
      const lastPointIndex = lastPath.getLength() - 1;
      const lastPoint = lastPath.getAt(lastPointIndex);

      // Buat marker dengan gambar dari URL untuk titik akhir
      const lastMarker = new google.maps.Marker({
        position: lastPoint,
        map: map,
        title: "Titik akhir",
        icon: {
          url:
            dataFAT.state == "Covered"
              ? "https://freepngimg.com/thumb/dollar/64022-green-symbol-dollar-sign-free-hq-image.png"
              : "https://cdn.pixabay.com/animation/2023/05/21/17/57/17-57-02-684__340.png",
          scaledSize: new google.maps.Size(45, 45), // Ukuran gambar marker
        },
      });
      // Update markers state
      setMarkers([firstMarker, lastMarker]);
      // Cleanup when unmounting
      return () => {
        firstMarker.setMap(null);
        lastMarker.setMap(null);
      };
    }
  }, [map, polylines]);

  const handleShowPanorama = () => {
    setShowPanorama(true); // Menampilkan panorama saat tombol diklik
  };

  // if (!routesLibrary || !map || !polylines.length) return null;

  return null;
}

export default Direction;
