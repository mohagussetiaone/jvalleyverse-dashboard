import React, { useState } from "react";
import InputGroup from "@/components/ui/InputGroup";
import { Icon } from "@iconify/react";
import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
} from "react-places-autocomplete";
import { useTitikLokasi, useFAT } from "@/store/Coordinate";
import Maps from "./Maps";
import DetailFAT from "./DetailFAT";
import Panorama from "./Panorama";
const LocationStreet = () => {
  const [address, setAddress] = useState("");
  const { setDataFAT, setAlamat, alamat } = useFAT();
  const [showPanorama, setShowPanorama] = useState(false);
  const { setDataDestination, setDataCurrentLokasi, currentLokasi } =
    useTitikLokasi();
  const [showMap, setShowMap] = useState(true);
  const handleAddressChange = (newAddress) => {
    setAddress(newAddress);
  };

  const handleSelect = async (selectedAddress) => {
    try {
      const results = await geocodeByAddress(selectedAddress);
      const latLng = await getLatLng(results[0]);
      console.log("Selected Address:", selectedAddress);
      console.log("Latitude and Longitude:", latLng);
      kirimData(parseFloat(latLng.lat), parseFloat(latLng.lng));
      setDataCurrentLokasi(latLng);
      setAddress(selectedAddress);
      setAlamat(selectedAddress);
    } catch (error) {
      console.error("Error selecting address:", error);
    }
  };

  async function kirimData(lat, lng) {
    console.log(import.meta.env.VITE_API_URL);
    setShowMap(false);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/survey`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          curlat: lat,
          curlon: lng,
          brand: "brand2",
          fat_point: 1,
          polyline: true,
        }),
      });
      const responseData = await response.json();
      console.log(responseData);
      console.log(`${import.meta.env.VITE_API_URL}/survey`);

      setDataDestination(responseData.data[0].fat.polyline);
      console.log(responseData.data[0]); // Anda dapat mengganti ini dengan tindakan yang sesuai dengan
      setDataFAT(responseData.data[0]);
      setShowMap(true);
    } catch (error) {
      console.error("Terjadi kesalahan:", error);
    }
  }

  return (
    <>
      <div>
        <label className={`block capitalize form-label`}>Enter Street</label>
        <PlacesAutocomplete
          value={address}
          onChange={handleAddressChange}
          onSelect={handleSelect}
        >
          {({
            getInputProps,
            suggestions,
            getSuggestionItemProps,
            loading,
          }) => (
            <div className="relative w-full mb-5 ">
              <div className="relative flex w-full ">
                <input
                  type="text"
                  label="Alamat lengkap"
                  className="pr-20"
                  {...getInputProps({
                    id: "website-admin",
                    className:
                      "rounded border text-gray-900 focus:ring-blue-500 focus:border-blue-500 block flex-1 min-w-0 w-full text-sm border-gray-400 p-2.5  dark:bg-gray-400 dark:border-gray-400 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                    placeholder: "Enter Street 1 Location ...",
                  })}
                />
              </div>

              <div
                className={`absolute z-10 left-0 mt-1 w-full bg-white  ${
                  suggestions.length > 0
                    ? "border border-gray-300 rounded-md shadow-lg "
                    : ""
                }`}
                style={{ top: "100%" }}
              >
                {loading && <div>Loading...</div>}
                {suggestions.map((suggestion) => (
                  <div
                    {...getSuggestionItemProps(suggestion)}
                    key={suggestion.placeId}
                    className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                  >
                    {suggestion.description}
                  </div>
                ))}
              </div>
            </div>
          )}
        </PlacesAutocomplete>
        {showMap == true ? (
          <>
            {showPanorama == true ? (
              <>
                <p
                  onClick={() => setShowPanorama(false)}
                  className="text-sm text-right mb-2 cursor-pointer "
                >
                  Back to maps
                </p>
                <Panorama />
              </>
            ) : (
              <>
                <p
                  onClick={() => setShowPanorama(true)}
                  className="text-sm text-right mb-2 cursor-pointer "
                >
                  Panorama
                </p>
                <Maps kirimData={kirimData} setAddress={setAddress} />
              </>
            )}

            <DetailFAT />
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </>
  );
};

export default LocationStreet;
