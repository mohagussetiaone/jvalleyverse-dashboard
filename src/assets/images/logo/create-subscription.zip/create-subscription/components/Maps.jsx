import React, { useEffect, useState, useRef } from "react";
import {
  APIProvider,
  Map,
  AdvancedMarker,
  useMap,
  useMapsLibrary,
} from "@vis.gl/react-google-maps";
import { useTitikLokasi } from "@/store/Coordinate";
import Direction from "./Direction";
function Maps({ setAddress, address, getGeocode, kirimData }) {
  const [map, setMap] = useState(null);
  const [isDraggingMarker, setIsDraggingMarker] = useState(false);
  const mapRef = useRef(null);
  const [showCenter, setShowCenter] = useState(false);
  const { setDataDestination, setDataCurrentLokasi, currentLokasi } =
    useTitikLokasi();

  const onMarkerDragStart = () => {
    setIsDraggingMarker(true);
  };

  // const onMarkerDragEnd = async (e) => {
  //     // waitingGif()
  //     const newPosition = {
  //         lat: e.latLng.lat(),
  //         lng: e.latLng.lng()
  //     };
  //     kirimData(newPosition.lat, newPosition.lng)

  //     setDataCurrentLokasi(newPosition)
  //     getGeocode(newPosition.lat, newPosition.lng, address)
  //     console.log("DARI MARKER" + JSON.stringify(newPosition));
  //     try {
  //         const response = await fetch(
  //             `https://maps.googleapis.com/maps/api/geocode/json?latlng=${e.latLng.lat()},${e.latLng.lng()}&key=${import.meta.env.VITE_GOOGLE_MAPS_APIKEY}`
  //         );

  //         if (!response.ok) {
  //             throw new Error('Failed to fetch address.');
  //         }

  //         const data = await response.json();
  //         console.log(data);
  //         if (data.results.length > 0) {
  //             setAlamat(data.results[0].formatted_address)
  //             setAddress(data.results[0].formatted_address);

  //         } else {
  //             setAlamat('')
  //             setAddress('');
  //         }
  //         setIsDraggingMarker(false);
  //     } catch (error) {
  //         console.error('Error fetching address:', error);
  //         setAddress('');
  //     }

  //     setClear(true)
  // };

  return (
    <APIProvider apiKey={import.meta.env.VITE_GOOGLE_MAPS_APIKEY}>
      <Map
        defaultCenter={currentLokasi}
        defaultZoom={20}
        className="h-96"
        mapId={"107b926848f1c1c0"}
      >
        {!isDraggingMarker && (
          <Direction kirimData={kirimData} setAddress={setAddress} />
        )}{" "}
      </Map>
    </APIProvider>
  );
}

export default Maps;
