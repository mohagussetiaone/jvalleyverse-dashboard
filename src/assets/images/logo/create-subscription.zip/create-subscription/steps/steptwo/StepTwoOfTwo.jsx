import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Select from "@/components/ui/Select";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import InputGroup from "@/components/ui/InputGroup";
import Icon from "@/components/ui/Icon";
import LocationStreet from "../../components/LocationStreet";
import ModalComp from "@/pages/subscription/components/ModalComp";

const styles = {
  option: (provided, state) => ({
    ...provided,
    fontSize: "14px",
  }),
};

const fruits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const StepTwoOfThree = ({ handleNext, handlePrev }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [value, setValue] = useState("");
  const [openModal, setOpenModal] = useState(false);
  const [dataAddress, setDataAddress] = useState();

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const stepSchema = yup.object().shape({
    company: yup.string().required("Company is required"),
    street: yup.string().required("Street is required"),
    country: yup.string().required("Country is required"),
    province: yup.string().required("Province is required"),
    city: yup.string().required("City is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });

  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };

  const handleSaveClick = () => {
    setOpenModal(false); // Menutup modal
    setDataAddress("Jl. Tebet Barat Dalam VI G No.3, RT.8/RW.4, Tebet Bar., Kec. Tebet, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12810, Indonesia");
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <Select label="Company" name="company" options={fruits} placeholder="Select Company " error={errors.company} register={register} />
        </div>
        <div className="flex gap-2 mt-4">
          <div className="w-4/12">
            <Textinput label="Postal Code" type="text" placeholder="Enter Postal Code" name="street" error={errors.street} register={register} />
          </div>
          <div className="w-8/12 mt-8">
            <div onClick={() => setOpenModal(true)}>
              <InputGroup
                type="text"
                placeholder="Click here to set street"
                append={
                  <span onClick={() => setOpenModal(true)}>
                    <Icon icon="bx:map" className="cursor-pointer" />{" "}
                  </span>
                }
                value={dataAddress}
                readonly
              />
            </div>
          </div>
        </div>
        <div className="mt-4">
          <div onClick={() => setOpenModal(true)}>
            <InputGroup
              label="Street 2"
              type="text"
              placeholder="Click here to set street"
              append={
                <span onClick={() => setOpenModal(true)}>
                  <Icon icon="bx:map" className="cursor-pointer" />{" "}
                </span>
              }
              value={dataAddress}
              readonly
            />
          </div>
        </div>
        <div className="lg:grid-cols-3 grid gap-5 grid-cols-1 mt-4">
          <div>
            <Select label="Country" name="country" options={fruits} placeholder="Select Country" error={errors.country} register={register} />
          </div>
          <div>
            <Select label="Province" name="province" options={fruits} placeholder="Select Province" error={errors.province} register={register} />
          </div>
          <div>
            <Select label="City" name="city" options={fruits} placeholder="Select City" error={errors.city} register={register} />
          </div>
        </div>
        <div className="flex justify-between mt-6">
          <Button onClick={() => handlePrev()} text="Back" className="btn-outline-primary" />
          <Button type="submit" text="Next" className="btn-primary shadow-base2" />
        </div>
      </form>
      <ModalComp
        title="Vertically center"
        label="Vertically center"
        labelClass="btn-outline-dark"
        uncontrol
        className="max-w-5xl"
        open={openModal}
        setOpen={setOpenModal}
        setDataAddress={setDataAddress}
        centered
        footerContent={<Button text="Save" className="btn-primary " onClick={handleSaveClick} />}
      >
        <LocationStreet />
      </ModalComp>
    </>
  );
};

export default StepTwoOfThree;
