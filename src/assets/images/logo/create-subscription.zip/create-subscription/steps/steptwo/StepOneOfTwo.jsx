import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Select from "@/components/ui/Select";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

const styles = {
  option: (provided, state) => ({
    ...provided,
    fontSize: "14px",
  }),
};

const fruits = [
  { value: "chocolate", label: "Choacolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const StepOneOfThree = ({ handleNext }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [value, setValue] = useState("A");

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const stepSchema = yup.object().shape({
    date: yup.string().required("Date is required"),
    partnerKSO: yup.string().required("Partner KSO is required"),
    ksoCode: yup.string().required("KSO Code is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
    setValue: setFormValue,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });

  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };

  const validateSelect = (value) => {
    if (value === "") {
      return "This field is required";
    }
    return true;
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <Textinput label="Date" type="date" placeholder="Type date" name="date" error={errors.date} register={register} />
        </div>
        <div className="mb-4">
          <Select label="Partner KSO" name="partnerKSO" options={fruits} placeholder="Select Partner KSO" value={setFormValue} error={errors.partnerKSO} register={register} />
        </div>
        <div className="mb-4">
          <Select label="KSO Code" name="ksoCode" options={fruits} placeholder="Select KSO Code " error={errors.ksoCode} register={register} />
        </div>
        <div className="mb-4">
          <label className={`block capitalize form-label`}>Type</label>
          <div className="flex space-xy-5 flex-wrap">
            <Radio label="RT/RW" name="type" value="A" checked={value === "A"} onChange={() => setValue("A")} />
            <Radio label="ISP" name="type" value="B" checked={value === "B"} onChange={() => setValue("B")} />
            <Radio label="Reseller" name="type" value="C" checked={value === "C"} onChange={() => setValue("C")} />
          </div>
        </div>
        <div className="flex justify-end mt-2">
          <Button text="Next" type="submit" className="btn-primary shadow-base2" />
        </div>
      </form>
    </>
  );
};

export default StepOneOfThree;
