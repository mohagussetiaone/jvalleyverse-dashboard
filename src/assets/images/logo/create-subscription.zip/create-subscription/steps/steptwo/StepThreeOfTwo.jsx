import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import Dropdown from "@/components/ui/Dropdown";
import InputGroup from "@/components/ui/InputGroup";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import Select from "@/components/ui/Select";
import { RiRepeatLine } from "react-icons/ri";

const fruits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const StepThreeOfThree = ({ handleNext, handlePrev }) => {
  const [value, setValue] = useState("FO");

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const stepSchema = yup.object().shape({
    // room: yup.string().required("Room is required"),
    rack: yup.string().required("Rack is required"),
    switch: yup.string().required("Switch is required"),
    port: yup.string().required("Port is required"),
    speed: yup.string().required("Speed is required"),
    vlan_company: yup.string().required("Vlan Company is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });

  const onSubmit = (data) => {
    console.log(data);
    handleNext();
  };

  return (
    <>
      <div className="w-full flex flex-col md:flex-row">
        <div className="w-5.5/12">
          <div className="mb-4">
            <Select label="Room" name="room" options={fruits} placeholder="Select a Room " error={errors.room} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Rack" type="text" placeholder="Enter Rack" name="rack" error={errors.rack} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Switch Id" type="text" placeholder="Enter switch" name="switch" error={errors.switch} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Port" type="text" placeholder="Enter Port" name="port" error={errors.port} register={register} />
          </div>
          <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
            <div className="mb-4">
              <label className={`block capitalize form-label`}>Type</label>
              <div className="flex space-xy-5 flex-wrap">
                <Radio label="FO" name="type" value="FO" checked={value === "FO"} onChange={handleChange} />
                <Radio label="UTP" name="type" value="UTP" checked={value === "UTP"} onChange={handleChange} />
              </div>
            </div>
            <div className="gap-2">
              <label htmlFor="speed" className="block capitalize form-label">
                Speed
              </label>
              <InputGroup
                type="text"
                placeholder="Enter Speed"
                name="speed"
                error={errors.speed}
                append={
                  <Dropdown
                    classMenuItems="right-0 w-[220px] top-[110%]"
                    className="h-full"
                    labelClass="h-full"
                    label={<Button text="Satuan UOM" className="btn-primary btn-sm" icon="heroicons-outline:chevron-down" iconPosition="right" div iconClass="text-lg" />}
                  />
                }
                register={register}
              />
            </div>
          </div>
          <div className="mb-6">
            <Textinput label="Vlan Company" type="text" placeholder="Enter Vlan Company" name="vlan_company" error={errors.vlan_company} register={register} />
          </div>
        </div>
        <div className="w-1/12 flex items-center justify-center">
          <RiRepeatLine className="text-center" />
        </div>
        <div className="w-5.5/12">
          <div className="mb-4">
            <Select label="Room" name="room" options={fruits} placeholder="Select Room " error={errors.room} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Rack" type="text" placeholder="Enter Rack" name="rack" error={errors.rack} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Switch Id" type="text" placeholder="Enter Switch" name="switch" error={errors.switch} register={register} />
          </div>
          <div className="mt-4">
            <Textinput label="Port" type="text" placeholder="Enter Port" name="port" error={errors.port} register={register} />
          </div>
          <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
            <div className="mb-4">
              <label className={`block capitalize form-label`}>Type</label>
              <div className="flex space-xy-5 flex-wrap">
                <Radio label="FO" name="type" value="FO" checked={value === "FO"} onChange={handleChange} />
                <Radio label="UTP" name="type" value="UTP" checked={value === "UTP"} onChange={handleChange} />
              </div>
            </div>
            <div className="gap-2">
              <label htmlFor="speed" className="block capitalize form-label">
                Speed
              </label>
              <InputGroup
                type="text"
                placeholder="Enter Speed"
                name="speed"
                error={errors.speed}
                append={
                  <Dropdown
                    classMenuItems="right-0 w-[220px] top-[110%]"
                    className="h-full"
                    labelClass="h-full"
                    label={<Button text="Satuan UOM" className="btn-primary btn-sm" icon="heroicons-outline:chevron-down" iconPosition="right" div iconClass="text-lg" />}
                  />
                }
                register={register}
              />
            </div>
          </div>
          <div className="mb-6">
            <Textinput label="Vlan Company" type="text" placeholder="Enter Vlan Company" name="vlan_company" error={errors.vlan_company} register={register} />
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-4 mt-2">
        <Button onClick={() => handlePrev()} text="Previouse" className="btn-outline-danger" />
        <Button onClick={handleSubmit(onSubmit)} text="Next" type="submit" className="btn-primary shadow-base2" />
      </div>
    </>
  );
};

export default StepThreeOfThree;
