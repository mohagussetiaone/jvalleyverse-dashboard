import React, { Fragment, useEffect, useState } from "react";
import StepOneOfTwo from "./StepOneOfTwo";
import StepTwoOfTwo from "./StepTwoOfTwo";
import StepThreeOfTwo from "./StepThreeOfTwo";
import { Tab } from "@headlessui/react";
import Icon from "@/components/ui/Icon";

const Index = ({ handleNextParent, currentSteps }) => {
  const buttons = [
    {
      title: "Data Partner KSO",
      icon: "heroicons-outline:user",
    },
    {
      title: "Location Interconnection",
      icon: "heroicons-outline:map-pin",
    },
    {
      title: "Company",
      icon: "heroicons-outline:building-office",
    },
  ];
  const [currentStep, setCurrentStep] = useState(0); // Set initial currentStep to 0

  useEffect(() => {
    console.log(currentStep);
  }, [setCurrentStep, currentStep]);
  const handleNext = () => {
    // Jika currentStep kurang dari jumlah tombol - 1, maka geser ke tab berikutnya
    if (currentStep < buttons.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    // Jika currentStep lebih besar dari 0, maka geser ke tab sebelumnya
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <>
      <Tab.Group selectedIndex={currentStep} onChange={setCurrentStep}>
        <div className="flex justify-center ">
          <Tab.List className="lg:space-x-8 md:space-x-4 space-x-0 rtl:space-x-reverse flex flex-col md:block">
            {buttons.map((item, i) => (
              <Tab as={Fragment} key={i}>
                {({ selected }) => (
                  <button
                    className={` inline-flex items-start text-sm font-medium mb-7 capitalize bg-white dark:bg-slate-800 ring-0 foucs:ring-0 focus:outline-none px-2 transition duration-150 before:transition-all before:duration-150 relative before:absolute
                     before:left-1/2 before:bottom-[-6px] before:h-[1.5px]
                      before:bg-primary-500 before:-translate-x-1/2
              
              ${selected ? "text-primary-500 before:w-full" : "text-slate-500 before:w-0 dark:text-slate-300"}
              `}
                  >
                    <span className="text-base relative top-[1px] ltr:mr-1 rtl:ml-1">
                      <Icon icon={item.icon} />
                    </span>
                    {item.title}
                  </button>
                )}
              </Tab>
            ))}
          </Tab.List>
        </div>
        <Tab.Panels>
          {buttons.map((item, i) => (
            <Tab.Panel key={i}>
              {i === 0 && <StepOneOfTwo handleNext={handleNext} />}
              {i === 1 && <StepTwoOfTwo handleNext={handleNext} handlePrev={handlePrev} />}
              {i === 2 && <StepThreeOfTwo handleNext={handleNextParent} handlePrev={handlePrev} />}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </>
  );
};

export default Index;
