import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Select from "@/components/ui/Select";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import InputGroup from "@/components/ui/InputGroup";
import Dropdown from "@/components/ui/Dropdown";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
const styles = {
  option: (provided, state) => ({
    ...provided,
    fontSize: "14px",
  }),
};

const furits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];
const StepCustomerTwo = ({ handleNext, handlePrev }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [value, setValue] = useState("");

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const stepSchema = yup.object().shape({
    technicalData: yup.string().required("Technical Data is required"),
    customer2: yup.string().required("Customer is required"),
    profitSharing: yup.string().required("Profit Sharing is required"),
    invoiceAddress: yup.string().required("Invoice Address is required"),
    deliveryAddress: yup.string().required("Delivery Address is required"),
    WHT: yup.string().required("WHT is required"),
    subsAmount: yup.string().required("Subscription Amount is required"),
    capacity: yup.string().required("Capacity is required"),
    output: yup.string().required("Output is required"),
    currency: yup.string().required("Currency is required"),
    company: yup.string().required("Company is required"),
    ksoPrepare: yup.string().required("Kso Prepare is required"),
  });

  const fruits = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "vanilla", label: "Vanilla" },
  ];
  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });
    const onSubmit = (data) => {
      if (data) {
        console.log(data);
        handleNext();
      }
    };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        {" "}
        <div className="mb-4">
          <Textinput
            label="Customer 2"
            type="text"
            placeholder="Type customer 2"
            error={errors.customer2}
            name="customer2"
            register={register}
          />
        </div>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
          <div className="mb-4">
            <label className={`block capitalize form-label`}>
              Profit Sharing
            </label>
            <InputGroup
              name="profitSharing"
              error={errors.profitSharing}
              register={register}
              type="text"
              placeholder="Type number"
              append="%"
            />
          </div>
          <div className="mb-4  gap-5">
            <Textinput
              label="Invoice Address Customer"
              type="text"
              error={errors.invoiceAddress}
              register={register}
              placeholder="Type Invoice Address"
              name="invoiceAddress"
            />
            {/* Tambahan komponen lainnya dapat ditambahkan di sini */}
          </div>
        </div>
        <div className="mb-4">
          <Select
            label="Delivery Address Customer 2"
            name="deliveryAddress"
            options={fruits}
            placeholder="Select Delivery Address"
            error={errors.deliveryAddress}
            register={register}
          />
        </div>
        <div className="lg:grid-cols-3 grid gap-5 grid-cols-1">
          <div className="mb-4">
            <Select
              label="WHT 21/23"
              name="WHT"
              options={fruits}
              placeholder="Select WHT 21/23"
              error={errors.WHT}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Textinput
              label="Subscription amount"
              type="text"
              placeholder="Type Subscription Amount"
              name="subsAmount"
              error={errors.subsAmount}
              register={register}
            />
          </div>
          <div className="mb-4  gap-5">
            <label htmlFor=" hh" className="form-label ">
              Capacity
            </label>
            <InputGroup
              type="text"
              name="capacity"
              register={register}
              error={errors.capacity}
              placeholder="Type Capacity"
              append={
                <Dropdown
                  classMenuItems="right-0  w-[220px] top-[110%] "
                  className="h-full"
                  labelClass="h-full"
                  label={
                    <Button
                      text="Satuan "
                      className="btn-outline-dark btn-sm"
                      icon="heroicons-outline:chevron-down"
                      iconPosition="right"
                      div
                      iconClass="text-lg"
                    />
                  }
                />
              }
            />
            {/* Tambahan komponen lainnya dapat ditambahkan di sini */}
          </div>
        </div>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
          <div className="mb-4">
            <Select
              label="Output"
              name="output"
              options={fruits}
              placeholder="Select Output"
              error={errors.output}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Textinput
              label="Currency"
              type="text"
              placeholder="Type Currency"
              name="currency"
              error={errors.currency}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Select
              label="Company"
              name="company"
              options={fruits}
              placeholder="Select Company"
              error={errors.company}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Textinput
              label="KSO Prepare Infrastructure"
              type="text"
              placeholder="Type KSO Prepare"
              name="ksoPrepare"
              error={errors.ksoPrepare}
              register={register}
            />
          </div>
        </div>
        <div className="flex justify-between mt-2">
          <Button
            onClick={() => handlePrev()}
            text="Back"
            className="btn-outline-primary"
          />
          <Button
            onClick={() => handleNext()}
            text="Next"
            type="submit"
            className="btn-primary shadow-base2"
          />
        </div>
      </form>
    </>
  );
};

export default StepCustomerTwo;
