import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Select from "@/components/ui/Select";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import AgreementLine from "./AgreementLine";

const styles = {
  option: (provided, state) => ({
    ...provided,
    fontSize: "14px",
  }),
};

const fruits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const StepCustomerOne = ({ handleNext }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [value, setValue] = useState("A");

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const stepSchema = yup.object().shape({
    date: yup.string().required("Date is required"),
    technicalData: yup.string().required("Technical Data is required"),
    billingAddress: yup.string().required("Billing Address is required"),
    ksoCode: yup.string().required("KSO Code is required"),
    customer1: yup.string().required("Customer 1 is required"),
    invoiceAddress: yup.string().required("Invoice Address is required"),
    deliveryAddress: yup.string().required("Delivery Address is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });
  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <Textinput label="Date" type="date" placeholder="Type date" name="date" error={errors.date} register={register} />
        </div>
        <div className="mb-4">
          <Select label="Technical Data" name="technicalData" options={fruits} placeholder="Select Technical Data" error={errors.technicalData} register={register} />
        </div>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
          <div className="mb-4">
            <label className={`block capitalize form-label`}>Billing Address</label>
            <div className="flex space-xy-5 flex-wrap">
              <Radio label="KSO" name="x" value="A" checked={value === "A"} onChange={handleChange} />
              <Radio label="Customer KSO" name="x" value="B" checked={value === "B"} onChange={handleChange} />
            </div>
          </div>
          <div className="mb-4">
            <label className={`block capitalize form-label`}>Type</label>
            <div className="flex space-xy-5 flex-wrap">
              <Radio label="RT/RW" name="x" value="A" checked={value === "A"} onChange={handleChange} />
              <Radio label="ISP" name="x" value="B" checked={value === "B"} onChange={handleChange} />
              <Radio label="Reseller" name="x" value="c" checked={value === "c"} onChange={handleChange} />
            </div>
          </div>
        </div>
        <div className="mb-4 gap-5">
          <Textinput label="KSO Code" type="text" placeholder="Automatic" name="ksoCode" error={errors.ksoCode} register={register} />
        </div>
        <div className="mb-4">
          <Select label="Customer 1" name="customer1" options={fruits} placeholder="Select Customer 1" error={errors.customer1} register={register} />
        </div>
        <div className="mb-4">
          <Select label="Invoice Address" name="invoiceAddress" options={fruits} placeholder="Select Invoice Address" error={errors.invoiceAddress} register={register} />
        </div>
        <div className="mb-4">
          <Select label="Delivery Address" name="deliveryAddress" options={fruits} placeholder="Select Delivery Address" error={errors.deliveryAddress} register={register} />
        </div>
        <div className="flex justify-end mt-2">
          <Button onClick={() => handleNext()} text="Next" type="submit" className="btn-primary shadow-base2" />
        </div>
      </form>
      <AgreementLine />
    </>
  );
};

export default StepCustomerOne;
