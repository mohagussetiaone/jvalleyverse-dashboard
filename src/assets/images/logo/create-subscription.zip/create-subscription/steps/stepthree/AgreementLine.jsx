import { useState } from "react";
import Textinput from "@/components/ui/Textinput";
import Select from "@/components/ui/Select";
import { MdDeleteOutline } from "react-icons/md";
import Button from "@/components/ui/Button";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useForm } from "react-hook-form";

const VLANPortService = () => {
  const [amountRender, setAmountRender] = useState(1);
  const [dataValues, setDataValues] = useState([
    {
      target_revenue: "",
      ps: "",
      product_category: "",
      product: "",
      bph_uso: "",
      based_ps: "",
      kso_ps_amount: "",
      company_ps: "",
    },
  ]);

  const optionsTagTransform = [
    { value: "Default", label: "Default" },
    { value: "Translate", label: "Translate" },
    { value: "Translate-and-add", label: "Translate-and-add" },
  ];

  const handleAddNew = () => {
    setAmountRender(amountRender + 1);
    setDataValues((prevColumns) => [
      ...prevColumns,
      {
        target_revenue: "",
        ps: "",
        product_category: "",
        product: "",
        bph_uso: "",
        based_ps: "",
        kso_ps_amount: "",
        company_ps: "",
      },
    ]);
  };

  const handleDelete = (index) => {
    if (index !== 0) {
      const updateDataVal = [...dataValues];
      updateDataVal.splice(index, 1);
      setDataValues(updateDataVal);
    }
  };

  const handleChange = (index, val, key) => {
    const updateDataVal = [...dataValues];
    updateDataVal[index][key] = val;
    setDataValues(updateDataVal);
  };

  const fruits = [
    { value: "chocolate", label: "Chocolate" },
    { value: "strawberry", label: "Strawberry" },
    { value: "vanilla", label: "Vanilla" },
  ];

  const targetRevenue = [
    { value: "1", label: "1" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
  ];

  const ps = [
    { value: "10%", label: "10%" },
    { value: "20%", label: "20%" },
    { value: "30%", label: "30%" },
    { value: "40%", label: "40%" },
  ];

  const headers = ["Target Revenue", "PS", "Product Category", "Product", "BPH Uso", "Based PS", "KSO PS Amount", "Company PS", "Action"];

  const stepSchema = yup.object().shape({
    startDate: yup.string().required("Start Date is required"),
    endDate: yup.string().required("End Date is required"),
    targetRevenue: yup.string().required("Target Revenue is required"),
    bphUso: yup.string().required("Invoice Address is required"),
    basedPs: yup.string().required("Delivery Address is required"),
    ksoPsAmount: yup.string().required("WHT is required"),
    companyPs: yup.string().required("Subscription Amount is required"),
    capacity: yup.string().required("Capacity is required"),
    output: yup.string().required("Output is required"),
    currency: yup.string().required("Currency is required"),
    company: yup.string().required("Company is required"),
    ksoPrepare: yup.string().required("Kso Prepare is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });
  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };

  return (
    <div className="border border-gray-200 p-4 my-6 rounded-md">
      <div className="flex mb-4">
        <div className="w-8/12">
          <p className="font-bold">Agreement Line</p>
        </div>
        <div className="w-4/12 flex gap-2 mr-0">
          <Textinput className="w-full" type="date" placeholder="Start Date" error={errors.startDate} register={register} />
          <Textinput className="w-full" type="date" placeholder="End Date" error={errors.endDate} register={register} />
        </div>
      </div>
      <div className="mb-2 ">
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-9 gap-2 mb-3">
          {headers.map((header, index) => (
            <div key={index} className="bg-blue-600 text-center rounded-lg">
              <p className="text-sm p-1 break-words justify-center items-center text-white">{header}</p>
            </div>
          ))}
        </div>
      </div>
      {dataValues.map((item, index) => {
        return (
          <div className="mb-2" key={index}>
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-9 gap-4 mb-3">
              <div>
                <Select name="target_revenue" options={targetRevenue} placeholder="4" onChange={(val) => handleChange(index, val, "target_revenue")} className="cursor-pointer" />
              </div>
              <div>
                <Select name="ps" options={ps} placeholder="10%" onChange={(val) => handleChange(index, val, "ps")} className="cursor-pointer" />
              </div>
              <div>
                <Select name="product_category" placeholder="-" onChange={(val) => handleChange(index, val, "product_category")} className="cursor-pointer" />
              </div>
              <div>
                <Select name="product" placeholder="-" onChange={(val) => handleChange(index, val, "product")} className="cursor-pointer" />
              </div>
              <div>
                <Textinput type="text" placeholder="-" name="bph_uso" error={errors.bphUso} register={register} />
              </div>
              <div>
                <Textinput type="text" placeholder="-" name="based_ps" error={errors.basedPs} register={register} />
              </div>
              <div>
                <Textinput type="text" placeholder="-" name="kso_ps_amount" error={errors.ksoPsAmount} register={register} />
              </div>
              <div>
                <Textinput type="text" placeholder="-" name="company_ps" error={errors.companyPs} register={register} />
              </div>
              <div className="flex flex-col justify-center items-center">
                <button onClick={() => handleDelete(index)}>
                  <MdDeleteOutline className="w-6 h-6 text-red-500 m-2" />
                </button>
              </div>
            </div>
            <hr className="my-4 border-1 border-gradient" />
          </div>
        );
      })}
      <div className="mb-3">
        <Button icon="ic:round-add" text="Add New" className="btn-primary btn-sm" onClick={handleAddNew} />
      </div>
    </div>
  );
};

export default VLANPortService;
