import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import "react-datepicker/dist/react-datepicker.css";
import Select from "@/components/ui/Select";
import Radio from "@/components/ui/Radio";
import Button from "@/components/ui/Button";
import InputGroup from "@/components/ui/InputGroup";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const styles = {
  option: (provided, state) => ({
    ...provided,
    fontSize: "14px",
  }),
};

const furits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const fruits = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];
const AgreementKSO = ({ handleNext, handlePrev }) => {
  const [startDate, setStartDate] = useState(new Date());
  const [value, setValue] = useState("");

  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const stepSchema = yup.object().shape({
    agreementStart: yup.string().required("Agreement Period Start is required"),
    agreementEnd: yup.string().required("Agreement Period End is required"),
    installation: yup.string().required("Installation is required"),
    activation: yup.string().required("Activation is required"),
    coorporationAgreement: yup
      .string()
      .required("Coorporation Agreement is required"),
    bhp: yup.string().required("BHP is required"),
    street2: yup.string().required("Street 2 is required"),
  });

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "onBlur",
  });
  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };

  return (
    <>
      {" "}
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
          <div className="mb-4">
            <Textinput
              label="Agreement Period Start"
              type="date"
              placeholder="Type date"
              name="agreementStart"
              error={errors.agreementStart}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Textinput
              label="Agreement Period End"
              type="date"
              placeholder="Type date"
              name="agreementEnd"
              error={errors.agreementEnd}
              register={register}
            />
          </div>
        </div>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1 mt-4">
          <div className="mb-4">
            <Select
              label="Installation"
              name="installation"
              options={fruits}
              placeholder="Select Installation"
              error={errors.installation}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Select
              label="Activation"
              name="activation"
              options={fruits}
              placeholder="Select Activation"
              error={errors.activation}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Select
              label="Coorporation Agreement"
              name="coorporationAgreement"
              options={fruits}
              placeholder="Select Coorporation Agreement"
              error={errors.coorporationAgreement}
              register={register}
            />
          </div>
          <div className="mb-4">
            <Select
              label="BHP USO"
              name="bhp"
              options={fruits}
              placeholder="Select BHP USO"
              error={errors.bhp}
              register={register}
            />
          </div>
        </div>
        <div className="">
          <label className={`block capitalize form-label`}>Street 2</label>
          <InputGroup
            name="street2"
            error={errors.street2}
            register={register}
            type="text"
            placeholder="Type street"
            append={<Button text="Search" className="btn-outline-dark " />}
          />
        </div>
        <div className="flex justify-between mt-8">
          <Button text="Back" className="btn-outline-primary" />
          <Button
            text="Next"
            type="submit"
            className="btn-primary shadow-base2"
          />
        </div>
      </form>
    </>
  );
};

export default AgreementKSO;
