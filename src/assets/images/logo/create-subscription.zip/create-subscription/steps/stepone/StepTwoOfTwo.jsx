import Radio from "@/components/ui/Radio";
import Textinput from "@/components/ui/Textinput";
import { useState } from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import InputGroup from "@/components/ui/InputGroup";
import Button from "@/components/ui/Button";
import Fileinput from "@/components/ui/Fileinput";
import ModalComp from "@/pages/subscription/components/ModalComp";
import SuccessImg from "../../../../../../public/img/others/success-create-1.png";
const stepSchema = yup.object().shape({
  email: yup.string().email("Invalid email address").required("Email is required"),
  phone: yup.string().required("Phone is required"),
  NIK: yup.string().required("NIK is required"),
});

const StepTwoOfTwo = ({ handlePrev }) => {
  const [selectedFile2, setSelectedFile2] = useState(null);
  const [openModal, setOpenModal] = useState(false);

  const handleFileChange2 = (e) => {
    setSelectedFile2(e.target.files[0]);
  };

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "all",
  });

  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      setOpenModal(true);
    }
  };
  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <Textinput label="Email" type="email" placeholder="Enter Email Address" name="email" error={errors.email} register={register} />
        </div>
        <div className="mb-4">
          <Textinput label="Phone" type="phone" placeholder="Enter Phone Number" name="phone" error={errors.phone} register={register} />
        </div>
        <div className="lg:grid-cols-2 grid gap-5 grid-cols-1">
          <div className="mb-4">
            <Textinput label="NIK" type="number" placeholder="Enter NIK" name="NIK" error={errors.NIK} register={register} />
          </div>
          <div className="mb-4">
            <label className={`block capitalize form-label`}>Upload KTP</label>
            <Fileinput name="basic" selectedFile={selectedFile2} onChange={handleFileChange2} preview />
          </div>
        </div>
        <div className="mb-4">
          <Textinput label="NPWP" type="text" placeholder="Type NPWP" name="NPWP" error={errors.NPWP} register={register} />
        </div>
        <div className="mb-4">
          <Textinput label="NIB" type="text" placeholder="Type NIB" name="NIB" error={errors.NIB} register={register} />
        </div>
        <div className="mb-4">
          <Textinput label="SPPKP" type="text" placeholder="Type SPPKP" name="SPPKP" error={errors.SPPKP} register={register} />
        </div>
        <div className="flex justify-between mt-8">
          <Button onClick={() => handlePrev()} text="Back" className="btn-outline-primary" />
          <Button type="submit" text="Create Partner KSO" className="btn-primary shadow-base2" />
        </div>
      </form>
      <ModalComp
        title="Vertically center"
        label="Vertically center"
        labelClass="btn-outline-dark"
        uncontrol
        open={openModal}
        setOpen={setOpenModal}
        centered
        footerContent={<Button text="Back to home" className="btn-primary block-btn" onClick={() => (window.location.href = "/subscription")} />}
      >
        <img src={SuccessImg} className="md:w-64 w-40 m-auto block" />
        <p className="font-bold text-xl text-center text-black">Success</p>
        <p className="text-center">Your data has sent to our System</p>
      </ModalComp>
    </>
  );
};

export default StepTwoOfTwo;
