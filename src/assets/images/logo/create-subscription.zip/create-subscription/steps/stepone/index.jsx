import { useState } from "react";
import StepOneOfTwo from "./StepOneOfTwo";
import StepTwoOfTwo from "./StepTwoOfTwo";

const index = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const handleNext = () => {
    setCurrentStep(2);
  };
  const handlePrev = () => {
    setCurrentStep(1);
  };
  return (
    <>
      {currentStep == 1 && <StepOneOfTwo handleNext={handleNext} />}
      {currentStep == 2 && <StepTwoOfTwo handlePrev={handlePrev} />}
  
    </>
  );
};

export default index;
