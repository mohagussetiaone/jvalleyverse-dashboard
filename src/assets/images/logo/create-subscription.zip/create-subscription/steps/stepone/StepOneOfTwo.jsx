import Radio from "@/components/ui/Radio";
import Textinput from "@/components/ui/Textinput";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import InputGroup from "@/components/ui/InputGroup";
import Button from "@/components/ui/Button";
import Select from "@/components/ui/Select";
import ModalComp from "@/pages/subscription/components/ModalComp";
import LocationStreet from "../../components/LocationStreet";
import Icon from "@/components/ui/Icon";
import { useFAT, useTitikLokasi } from "@/store/Coordinate";
const stepSchema = yup.object().shape({
  company_name: yup.string().required("Company Name is required"),
  // company_reference: yup.string().required("Company Reference is required"),
  reference: yup.string().required("Reference is required"),
  country: yup.string().required("Country is required"),
  city: yup.string().required("City is required"),
  province: yup.string().required("Province is required"),
  sub_district: yup.string().required("Sub district is required"),
  district: yup.string().required("District is required"),
  postal_code: yup.string().required("Postal code is required"),
  fat_latitude: yup.string().required("Fat Latitude is required"),
  fat_longitude: yup.string().required("Fat Longitude is required"),
  shortest_entity: yup.string().required("Shortest Entity is required"),
  distance_to_fat: yup.string().required("Distance to FAT is required"),
  street1: yup.string().required("Street 1 is required"),
});

const companyReference = [
  { value: "1", label: "PT Remala Abadi" },
  { value: "2", label: "PT Fibermedia Indonesia" },
  { value: "3", label: "PT Solusi Aplikasi Andalan Semesta" },
];

const StepOneOfTwo = ({ handleNext }) => {
  const [value, setValue] = useState("");
  const [openModal, setOpenModal] = useState(false);
  const [dataAddress, setDataAddress] = useState("");
  const { alamat, dataFAT } = useFAT();
  const { currentLokasi } = useTitikLokasi();
  const [dataLokasi, setDataLokasi] = useState({
    level1: "",
    level2: "",
    level3: "",
    level4: "",
    level5: "",
    postal_code:""
  });

  const [detailFAT, setDetailFAT] = useState({
    fat: {
      latitude: "",
      longitude: "",
      radius_distance: "",
    },
  });

  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const onSubmit = (data) => {
    if (data) {
      console.log(data);
      handleNext();
    }
  };
  const handleDataLokasiChange = (fieldName, event) => {
    setDataLokasi((prevState) => ({
      ...prevState,
      [fieldName]: event.target.value,
    }));
  };


  async function getLocation() {
    try {
      const response = await fetch(
        `https://mapi.tachyon.net.id:2443/api/geocoder`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            latitude: currentLokasi.lat,
            longitude: currentLokasi.lng,
          }),
        }
      );
      const responseData = await response.json();
      console.log(responseData);
      setDataLokasi(responseData)
    } catch (error) {
      console.error("Terjadi kesalahan:", error);
    }
  }

  const {
    register,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm({
    resolver: yupResolver(stepSchema),
    mode: "all",
  });

  function convertDistance(value) {
    if (value) {
      if (value >= 1000) {
        const kilometers = value / 1000;
        return `${kilometers.toFixed(2)} km`;
      } else {
        return `${value} m`;
      }
    } else {
      return `Rute not found`;
    }
  }

  const handleSaveClick = () => {
    setOpenModal(false); // Menutup modal
    console.log(alamat);
    setDataAddress(alamat);
    setDetailFAT(dataFAT);
    getLocation();
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="flex space-xy-5 flex-wrap">
          <Radio
            label="Individual"
            name="x"
            value="A"
            checked={value === "A"}
            onChange={handleChange}
          />
          <Radio
            label="Company"
            name="x"
            value="B"
            checked={value === "B"}
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <Textinput
            label="Company Name"
            type="text"
            placeholder="Enter Company Name"
            name="company_name"
            error={errors.company_name}
            register={register}
          />
        </div>
        <div className="mb-4">
          <Select
            label="Company Reference"
            name="companyReference"
            options={companyReference}
            placeholder="Select company reference"
            error={errors.company_reference}
            register={register}
          />
        </div>
        <div className="mb-4">
          <Textinput
            label="Reference"
            type="text"
            placeholder="Enter Reference"
            name="reference"
            error={errors.reference}
            register={register}
          />
          <div className="mt-4">
            <label className={`block capitalize form-label`}>Street</label>
            <div onClick={() => !dataAddress && setOpenModal(true)}>
              <InputGroup
                type="text"
                name="street1"
                error={errors.street1}
                value={dataAddress}
                onChange={(e) => setDataAddress(e.target.value)}
                register={register}
                placeholder="Click here to set street"
                append={
                  <span onClick={() => setOpenModal(true)}>
                    <Icon icon="bx:map" className="cursor-pointer" />{" "}
                  </span>
                }
              />
            </div>
            {dataAddress && (
              <p className="text-xs text-red-400 mb-4">
                * Edit with correct data street *
              </p>
            )}
          </div>
          <div className="lg:grid-cols-3 grid gap-5 grid-cols-1">
            <div className="mb-4">
              <Textinput
                label="Country"
                type="text"
                placeholder="Enter Country"
                name="country"
                error={errors.country}
                register={register}
                onChange={(e) => handleDataLokasiChange("level1", e)}
              />
            </div>
            <div className="mb-4">
              <Textinput
                label="City"
                type="text"
                placeholder="Enter City"
                name="city"
                error={errors.city}
                register={register}
                value={dataLokasi.level2}
                onChange={(e) => handleDataLokasiChange("level2", e)}
              />
            </div>
            <div className="mb-4">
              <Textinput
                label="Province"
                type="text"
                placeholder="Enter Province"
                name="province"
                error={errors.province}
                register={register}
                value={dataLokasi.level1}
                onChange={(e) => handleDataLokasiChange("level1", e)}
              />
            </div>
            <div className="mb-4">
              <Textinput
                label="Sub District"
                type="text"
                placeholder="Enter Sub District"
                name="sub_district"
                error={errors.sub_district}
                register={register}
                value={dataLokasi.level4}
                onChange={(e) => handleDataLokasiChange("level14", e)}
              />
            </div>
            <div className="mb-4">
              <Textinput
                label="District"
                type="text"
                placeholder="Enter District"
                name="district"
                error={errors.district}
                register={register}
                value={dataLokasi.level3}
                onChange={(e) => handleDataLokasiChange("level3", e)}
              />
            </div>
            <div className="mb-4">
              <Textinput
                label="Postal Code"
                type="number"
                placeholder="Enter Postal Code"
                name="postal_code"
                error={errors.postal_code}
                register={register}
                value={dataLokasi.postal_code}
                onChange={(e) => handleDataLokasiChange("postal_code", e)}
              />
            </div>
          </div>
          <div className="lg:grid-cols-2 grid gap-5 grid-cols-1">
            <Textinput
              label="Fat Latitude"
              type="text"
              placeholder="Enter Fat Latitude"
              name="fat_latitude" // Ubah name menjadi sesuai dengan field yang diinginkan
              error={errors.fat_latitude} // Ubah error sesuai dengan field yang diinginkan
              register={register}
              value={detailFAT.fat.latitude}
            />
            <Textinput
              label="Fat Longitude"
              type="text"
              placeholder="Enter Fat Longitude"
              name="fat_longitude" // Ubah name menjadi sesuai dengan field yang diinginkan
              error={errors.fat_longitude} // Ubah error sesuai dengan field yang diinginkan
              register={register}
              value={detailFAT.fat.longitude}
            />
            <Textinput
              label="Shortest Entity"
              type="text"
              placeholder="Enter Shortest Entity"
              name="shortest_entity" // Ubah name menjadi sesuai dengan field yang diinginkan
              error={errors.shortest_entity} // Ubah error sesuai dengan field yang diinginkan
              register={register}
            />
            <Textinput
              label="Distance to FAT"
              type="text"
              placeholder="Enter Distance To Fat"
              name="distance_to_fat" // Ubah name menjadi sesuai dengan field yang diinginkan
              error={errors.distance_to_fat} // Ubah error sesuai dengan field yang diinginkan
              register={register}
              value={convertDistance(detailFAT.fat.radius_distance)}
            />
          </div>
        </div>
        <div className="flex justify-end mt-2">
          <Button
            text="Next"
            type="submit"
            className="btn-primary shadow-base2"
          />
        </div>
      </form>


      <ModalComp
        title="Vertically center"
        label="Vertically center"
        labelClass="btn-outline-dark"
        uncontrol
        className="max-w-5xl"
        open={openModal}
        setOpen={setOpenModal}
        setDataAddress={setDataAddress}
        centered
        footerContent={
          <Button
            text="Save"
            className="btn-primary "
            onClick={handleSaveClick}
          />
        }
      >
        <LocationStreet />
      </ModalComp>
    </>
  );
};

export default StepOneOfTwo;
